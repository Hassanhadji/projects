package seg3102.group25.wellmeadows.hmspms.contracts

import io.cucumber.spring.CucumberContextConfiguration
import org.springframework.boot.test.context.SpringBootTest

@CucumberContextConfiguration
@SpringBootTest
class CucumberBootstrap{
}