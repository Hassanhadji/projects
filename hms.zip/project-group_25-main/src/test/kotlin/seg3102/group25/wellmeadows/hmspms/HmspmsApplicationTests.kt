package seg3102.group25.wellmeadows.hmspms

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class HmspmsApplicationTests {

	@Test
	fun contextLoads() {
	}

}
