package seg3102.group25.wellmeadows.hmspms.domain.supply.facade.implementation

class MedicationFacadeImpl {
}