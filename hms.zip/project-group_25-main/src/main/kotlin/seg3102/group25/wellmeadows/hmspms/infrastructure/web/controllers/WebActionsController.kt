package seg3102.group25.wellmeadows.hmspms.infrastructure.web.controllers

import org.springframework.stereotype.Controller

@Controller
class WebActionsController {


}