package seg3102.group25.wellmeadows.hmspms.domain.common

interface DomainEvent