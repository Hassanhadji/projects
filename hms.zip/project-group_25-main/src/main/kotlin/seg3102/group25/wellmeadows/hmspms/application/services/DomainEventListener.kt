package seg3102.group25.wellmeadows.hmspms.application.services

interface DomainEventListener {
}