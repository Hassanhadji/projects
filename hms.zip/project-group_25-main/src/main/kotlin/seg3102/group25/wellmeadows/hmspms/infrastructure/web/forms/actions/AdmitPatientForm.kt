package seg3102.group25.wellmeadows.hmspms.infrastructure.web.forms.actions

class AdmitPatientForm {
    var patientNumber: String? = null
    var localDoctor: String? = null
    var roomNumber: String? = null
    var bedNumber: String? = null
    var privateInsuranceNumber: String? = null
}