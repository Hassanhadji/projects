package seg3102.group25.wellmeadows.hmspms.application.dtos.queries

data class VisualizeDivisionDTO(
    var chargeNurseID: String,
    var divisionId: String
)