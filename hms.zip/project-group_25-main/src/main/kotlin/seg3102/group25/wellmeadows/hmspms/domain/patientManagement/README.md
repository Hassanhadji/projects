<h1>Patient Management Sub-Domain</h1>

<h2>Core</h2>

<p>
This subdomain is the core of the PMS system. It will contain instances of each treatment which will have references
to instances of staff, patient, facilities and other domains.
</p>

<h3>Rationale</h3>
<p>  This domain will have to be manually created 
as it is not available off the shelf. It also comprises the core features of the PMS system. Therefore, this is our core domain
</p>


<!-- <h3>Relevant Functional Requirements</h3>
<ul>
<li>
</li>
</ul>

<h3>Relevant Use Cases</h3>
<ul>
<li>
</li>
<li></li>
<li></li>
</ul>
-->