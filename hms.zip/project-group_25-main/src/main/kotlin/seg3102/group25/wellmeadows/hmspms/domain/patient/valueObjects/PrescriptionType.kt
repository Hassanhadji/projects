package seg3102.group25.wellmeadows.hmspms.domain.patient.valueObjects

enum class PrescriptionType {
    Medication,
    Error
}