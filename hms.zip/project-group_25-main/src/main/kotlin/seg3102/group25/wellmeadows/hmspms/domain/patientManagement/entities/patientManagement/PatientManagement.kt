package seg3102.group25.wellmeadows.hmspms.domain.patientManagement.entities.patientManagement

class PatientManagement() {
    // Core Components
    // UI interfaces Here - Link to all Use Cases (View Facade)
}