package seg3102.group25.wellmeadows.hmspms.application.dtos.queries

data class StaffLogInDTO(
    var userId: String,
    var password: String,
)