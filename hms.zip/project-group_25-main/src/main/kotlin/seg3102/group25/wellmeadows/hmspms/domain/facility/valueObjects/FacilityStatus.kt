package seg3102.group25.wellmeadows.hmspms.domain.facility.valueObjects

enum class FacilityStatus {
    Complete,
    Incomplete
}