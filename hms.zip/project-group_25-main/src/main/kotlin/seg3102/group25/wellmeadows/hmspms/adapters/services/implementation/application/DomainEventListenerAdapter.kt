package seg3102.group25.wellmeadows.hmspms.adapters.services.implementation.application

import org.springframework.stereotype.Component
import seg3102.group25.wellmeadows.hmspms.application.services.DomainEventListener

@Component
class DomainEventListenerAdapter: DomainEventListener {
}