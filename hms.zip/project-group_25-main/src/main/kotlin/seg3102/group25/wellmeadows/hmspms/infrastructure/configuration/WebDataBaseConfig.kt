package seg3102.group25.wellmeadows.hmspms.infrastructure.configuration

import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration

@Configuration
class WebDataBaseConfig {

}