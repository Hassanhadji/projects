package seg3102.group25.wellmeadows.hmspms.domain.constituent.valueObjects

enum class ConstituentType {
    NextOfKin
}