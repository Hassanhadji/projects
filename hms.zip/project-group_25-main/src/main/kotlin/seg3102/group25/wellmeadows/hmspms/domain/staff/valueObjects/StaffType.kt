package seg3102.group25.wellmeadows.hmspms.domain.staff.valueObjects

enum class StaffType{
    MedicalDirector,
    PersonnelOfficer,
    LocalDoctor,
    ExternalDoctor,
    Nurse,
    Auxiliary,
    ChargeNurse,
    SpecialistStaff,
}