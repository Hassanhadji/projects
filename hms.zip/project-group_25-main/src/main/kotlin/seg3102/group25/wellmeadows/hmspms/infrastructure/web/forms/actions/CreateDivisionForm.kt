package seg3102.group25.wellmeadows.hmspms.infrastructure.web.forms.actions

class CreateDivisionForm {
    var divisionId: String? = null
    var divisionName: String? = null
    var chargeNurseFirstName: String? = null
    var chargeNurseLastName: String? = null
    var chargeNurseTelExtension: String? = null
    var chargeNurseBipExtension: String? = null
    var location: String? = null
    var numberBeds: Int? = null
    var telephoneExtension: String? = null
}