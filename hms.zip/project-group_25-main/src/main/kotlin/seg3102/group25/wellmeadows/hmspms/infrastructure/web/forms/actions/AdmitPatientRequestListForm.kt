package seg3102.group25.wellmeadows.hmspms.infrastructure.web.forms.actions

class AdmitPatientRequestListForm {
    var patientId: String? = null
    var chargeNurseId: String? = null
    var divisionID: String? = null
    var admissionStatus: String? = null
}