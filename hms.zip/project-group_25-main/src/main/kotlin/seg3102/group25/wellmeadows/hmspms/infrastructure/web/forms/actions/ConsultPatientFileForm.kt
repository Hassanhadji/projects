package seg3102.group25.wellmeadows.hmspms.infrastructure.web.forms.actions

class ConsultPatientFileForm {
    var staffId: String? = null
    var patientId: String? = null
}